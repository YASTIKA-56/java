package com.Sonata;

public class DuplicateCount
{
	public static void main(String arg[])
    {
  
        int A[] = { 1, 6, 4, 6, 4, 8, 2, 4, 1, 1 };
  
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < A.length; i++)
        {
            if (A[i] > max)
                max = A[i];
        }
  
        int B[] = new int[max + 1];
        for (int i = 0; i < A.length; i++) 
        {
  
            // increment in array B for every integer
            // in A.
            B[A[i]]++;
        }
        for (int i = 0; i <= max; i++)
        {
           
            if (B[i] > 1)
                System.out.println(i + "-" + B[i]);
        }
    }
}


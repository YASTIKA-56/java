package com.Sonata;

public class Ass2
{
	public static void main(String arg[]) 

	{
		int num=2;
		int s = num*num*num;
		System.out.println("the cube of number:"+ s);
	}
}

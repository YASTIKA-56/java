package com.Sonata;

public class Dubplicate
{
	 public static void main(String[] args) 
	    {
	int[] arr = new int[5];
	arr[0] = 1;
	arr[1] = 4;
	arr[2] = 3;
	arr[3] = 4;

	
	for (int i = 0; i <arr.length-1; i++)
	{ 
		for (int j = i + 1 ; j < arr.length-1; j++)
		{ 
			if (arr[i]==(arr[j])) 
		  System.out.println(" duplicate arr : "+ arr[j]);
		}

	}
	}
}
		
package com.Sonata;

public class Ass1 {
	public static void main(String arg[]) 

{
		int num1,num2,num3 ;
		num1= 12;
		num2= 25;
		num3= 89;

		  if (num1>= num2 && num1 >= num3)//
			  
	           System.out.println("Num1 is greatest :"+num1);
	   
	        else if (num2 >= num1 && num2>= num3)
	 
	        	  System.out.println("Num2 is greatest :"+num2);
	 
	        else
	 
	        	  System.out.println("Num3 is greatest :"+num3);
}

}

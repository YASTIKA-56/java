package com.Sonata;

public class Asss3 
{
	public static void main(String arg[]) 

	{
		int[] arr = new int[5];
		arr[0] = 1;
		arr[1] = 2;
		arr[2] = 3;
		arr[3] = 4;
		arr[4] = 5;
		
		int sum = 0;
		for(int i=0;i<=arr.length-1;i++)
		{
			 sum =sum + arr[i];
	}
		System.out.println("the sum of number:"+ sum);
}
}
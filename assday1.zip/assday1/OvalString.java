package com.Sonata;

public class OvalString 
{
	 public static void main(String[] arg)
	 {
	          String b= new String("rajubighjaodsezxu");
	          
	        char ch[]= b.toCharArray();
	        
	        for (int i = 0; i <ch.length-1; i++)
	        {
	               if (ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||ch[i]=='o'||ch[i]=='u')
	               {
	                ch[i]='$'; //replacing $ in the place of vowels
	               }   
	        }
	        for (int i = 0; i < ch.length; i++) 
	        {
	            System.out.print(ch[i]);
	        }
	    }

}

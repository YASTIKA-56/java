package com.Sonata;

public class MyOwnAutoShop 
{
	public static void main(String args[])
	{
		Ford f1 = new Ford();//object CREATION 
		f1.year = 1998; 
		f1.manufacturerDiscount= 78; 
		f1.speed=98;
		f1.color="blue";
		f1.display();
		System.out.println();
		double salePriceford = f1.getSalePrice();
		
		Sedan s1 = new Sedan(80,"red", 9888,99);
		double salePricesedan = s1.getSalePrice();
		s1.display();
		System.out.println();
		
	     Ford f2 = new Ford(34,"pink",453,455,99);
	     double salePricefords = f2.getSalePrice();
		f2.display();
		System.out.println();
	
		 
	}
}

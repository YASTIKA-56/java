package com.Sonata;

public class Car 
{
	int speed; 
	double regularPrice; 
	String color; 
	
	
	 //default constructor
	 Car(){}
	 
	 
	  //parameter constructor
	Car(int a,String n, double d)
	 {
		 this.speed=a;
		 this.color=n;
		 this.regularPrice=d;
	 }
	 
	 public double getSalePrice()
	 {
		 return regularPrice;
	 }
	  
	 public void display() {
			System.out.println("Speed" + speed);
			System.out.println("Color" + color);
			System.out.println("Regular Price " + regularPrice);

		}

}

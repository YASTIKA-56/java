package com.Sonata;

public class Ford  extends Car
{
	int year; 
	int manufacturerDiscount; 
	

	Ford(int a,String n, double d,int ye, int manu)
	{
		super(a ,n ,d );
		this.year = ye;
		this.manufacturerDiscount = manu;
		}
	Ford(){}
	
	public  double getSalePrice()
	{
		return regularPrice =( regularPrice - manufacturerDiscount)/100;
	}

	
	public  void display()
	{
	super.display();
	System.out.println("year"+ year);
		
	}
}

package com.Sonata;

public class Productclass {

	int proid;
	 String proname;
	 double proprice;
	 
	 //default constructor
	 Productclass(){}
	 
	 //parameterized
	 Productclass(int id,String name, double price)
	 { 
		this.proid = id;
		this.proname = name;
		this. proprice = price;
	 }
	 
	
	 public void display()
	 {
		 System.out.println(proid);
		 System.out.println(proname);
		 
		 }
	 
	 public double totalprice(double gst) 
	 {
		 
		return this.proprice+ gst; 
	 }
	 
	 
	 public static void main(String args[])
		{
			Productclass p1 = new Productclass(80,"iiu",9);
			p1.display();
			System.out.println(p1.totalprice(10));
		    
	}
}

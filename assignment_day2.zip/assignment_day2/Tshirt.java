




package com.Sonata;

public class Tshirt 
{

	 String material;
	 String color;
	String design;
	

	
	public void display()
	 {
		 System.out.println( material);
		 System.out.println(color);
		 System.out.println(design);
	 }
	
	public static void main(String args[])
	{
		Tshirt small = new Tshirt();//object CREATION 
		small.material = "cotton";
		small.color = "pink";
		small.design =" traditional";
		small.display();
		 System.out.println(" ");
		Tshirt large = new Tshirt();//object
		large.material = "nylon";
		large.color = "blue";
		large.design = "western";
		large.display();
		 System.out.println(" ");
		Tshirt xl = new Tshirt();//object
		xl.material = "linon";
		xl.color = "yellow";
		xl.design = "western";
		xl.display();
	}
}



package com.Sonata;

public class Sedan extends Car
{
	int length; 
	
	Sedan(){}

	Sedan(int a,String n, double d,int length)
	{
		super(a ,n ,d );
		this.length = length;
	}
	
	 

	public double  getSalePrice( double regularPrice)
	{
		
		if( length>20)
		{
			 return regularPrice = (5/100) * regularPrice;
		}
		else 
		{
		return  regularPrice = (10/100) * regularPrice;
		}
		
	}
	
	 public void display()
	 {
		 super.display();
		 System.out.println("length"+ length);
	 }
}

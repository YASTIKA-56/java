package com.Sonata;

public class StudentAss 

{
	
	int stuid;
	 String stuname;
	 
	 public void display()
	 {
		 System.out.println(stuid);
		 System.out.println(stuname);
		
	 }
	 
	
	 
	 public static void main(String args[])
		{
			Student s1 = new Student();
			s1.stuid = 12;
			s1.stuname = "reena";
			s1.display();
		
	}
}





package com.Sonata;

public class Truck extends Car
{
	int weight; 
	
	 Truck(){}
	 
  Truck(int a,String n, double d,int weight)
	{
		super(a ,n ,d );
		this.weight = weight;
	}
  
	 
  
  
	 public double getSalePrice()
	 {
		
		if(weight>2000)
		{
			return regularPrice = 10 * (regularPrice/100);
		}
		 else
		 {
			 return regularPrice = 20 * (regularPrice/100);
		}
			 
	 }
	 public void display()
	 {
		 super.display();
		 System.out.println("weigth"+ weight);
	 }

	 

}

package com.Sonata;

public class Triangle  extends Square 
{
	public int area(int d,int e) {
		this.a=d*e/2;
		return a;
	}
	public static void main(String[] args) {
		
		Triangle t=new  Triangle ();
		t.area(70,10);
		t.display();
	}
}

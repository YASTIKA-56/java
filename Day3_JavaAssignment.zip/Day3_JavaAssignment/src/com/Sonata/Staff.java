package com.Sonata;

public class Staff   extends Employee{

	String title;
	
	@Override
	 double salcal() {
		
		double hra = 0.18*basicpay;
		return basicpay + hra;
		
	}
	
	@Override
	public String toString() {
		return "Staff [empid=" + empid + ", empname=" + empname +" "];
	}
	
	public static void main (String args[]) {
		Staff s= new Staff();
		Address a=new Address();
		a.setCity("ujire");
		a.setDoorno(67);
		a.setPin(574240);
		
		
		s.basicpay  =100;
		s.empid =11;
		s.empname ="iii";
		s.obj = a;
		System.out.println("empid : "+s.empid);
		System.out.println("empname : "+s.empname);
		System.out.println("Adress : "+s.obj);
		System.out.println("salary for tech emp:"+s.salcal());
	
	}
	

}

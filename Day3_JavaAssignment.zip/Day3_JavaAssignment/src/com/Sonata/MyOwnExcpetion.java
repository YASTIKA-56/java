package com.Sonata;

public class MyOwnExcpetion   extends Exception {

	MyOwnExcpetion(String s)
	{
		super(s);
	}
}

package com.Sonata;

public class EmpSalChe   extends Exception 
{
	public static void main(String[] args) throws MyOwnExcpetion{
		int qsal=10000;
		if(qsal<100000) {
			throw new MyOwnExcpetion("Employee Annual Salary is less than 100000");
		}
		else System.out.println("Employee Annual Salary is more than 100001");
	}
}

package com.Sonata;

public class Developer extends Emp {
	 
	Developer(int q,String s)
	{
		this.empid = q;
		this.empname = s;
	}
	public  double salcal(int q)
	{
		this.empsal = q*1.2;
		return this.empid;
	}
	public static void main(String[] args)
	{
		Developer e1 = new Developer(123,"yastika");
		e1.salcal(8778);
		e1.display();
	}
}

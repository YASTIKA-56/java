package com.Sonata;

public class Rectangle extends Square {
	public int area(int f,int g) {
		this.a=f*g;
		return a;
	}
	public static void main(String[] args) {
		Rectangle u = new Rectangle();
		u.area(3,8);
		u.display();
	}
}

package com.Sonata;

public class Tester extends Emp {

	Tester(int q,String s){
		 
		this.empid=q;
		this.empname=s;
	}
	public double salCal(int q) {
		this.empsal = q*1.1;
		return this.empsal;
	}
	public static void main(String[] args) {
		
		Tester e1= new Tester(123,"yastika");
		e1.salCal(8778);
		e1.display();
	}

}

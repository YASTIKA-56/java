package com.Sonata;

public class Manager extends Emp {

	Manager(int q,String s)
	{
		this.empid = q;
		this.empname = s;
	}
	public  double salcal(int q)
	{
		this.empsal = q*1.4;
		return this.empid;
	}
	public static void main(String[] args)
	{
		Developer e1 = new Developer(123,"yastika");
		e1.salcal(8778);
		e1.display();
	}
}

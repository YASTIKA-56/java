package com.Sonata;

public class Address {
   private String city;
   private int pin ;
   private int doorno;
   public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getPin() {
	return pin;
}
public void setPin(int pin) {
	this.pin = pin;
}
public int getDoorno() {
	return doorno;
}
public void setDoorno(int doorno) {
	this.doorno = doorno;
}
private String getcity() {
	  return city;
   }
   
}

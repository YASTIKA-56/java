package com.Sonata;

public  abstract class Employee {
	
	int empid;
	String empname;
	double Emppay;
	Address obj;
	int leave;
	abstract double salcal();
	

}

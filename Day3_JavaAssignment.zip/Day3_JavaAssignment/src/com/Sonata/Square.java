package com.Sonata;

public class Square {
int a;
	
	public int area(int l) {
		this.a=l*l;
		return a;
	}
	public void display() {
		System.out.println("Area  "+this.a+" squnits");
	}
	public static void main(String[] args) {
		
		Square s=new Square();
		s.area(10);
		s.display();
	}
}

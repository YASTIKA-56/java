package com.Sonata;

public class TechnicalEmp  extends Employee{

String skills;
	
	@Override
	 double salcal() {
		
		double hra=0.12 * basicpay;
		return basicpay + hra;
		
	}
	
	@Override
	public String toString() {
		return "TechnicalEmp [eid=" + empid + ", empname=" + empname +"]";
	}
	
	public static void main (String args[]) {
		Address a=new Address();
		a.setCity("ujire");
		a.setDoorno(67);
		a.setPin(574240);
		
		TechnicalEmp t= new TechnicalEmp();
		t.basicpay = 100;
		t.empid=10;
		t.empname="yastika";
		t.obj=a;
		System.out.println("eid : "+t.empid);
		System.out.println("ename : "+t.empname);
		System.out.println("Adress : "+t.obj);
		System.out.println("salary for tech emp:"+t.salcal());
	}

}

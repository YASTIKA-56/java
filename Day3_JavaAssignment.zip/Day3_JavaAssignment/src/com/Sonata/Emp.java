package com.Sonata;

public class Emp {

	int empid;
	String empname;
	double empsal;
	
	Emp(){}
	
	Emp(int a,String b){
 
		this.empid=a;
		this.empname=b;
	}
			
	public double salcal(int a) {
		this.empsal=a;
		return this.empsal;
	}
	
	public void display() {
		System.out.println("Emp Id : "+empid);
		System.out.println("Emp Name : "+empname);
		System.out.println("Emp Sal : "+empsal);	
		System.out.println();
	}
	public static void main(String[] args) {
		
		Emp e1= new Emp(123,"yastika");
		e1.salcal(8778);
		e1.display();
	}
}
